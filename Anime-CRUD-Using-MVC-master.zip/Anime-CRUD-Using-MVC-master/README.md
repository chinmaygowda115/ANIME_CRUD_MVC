# Anime-CRUD-Using-MVC

### To Run the Assignment
 - Git Clone The Repository 
 ```
 git clone https://github.com/yoyozaemon/Anime-CRUD-Using-MVC.git 
 ```
 
 - Change the Current Directory
 ```
 cd Anime-CRUD-Using-MVC
 ```
 - Install the Maven Package for the Assignment
 ```
 mvn install
 &
 mvn clean install
 ```
 - To execute the code
 ```
 mvn spring-boot:run
 ```
 - Open the Any Browser and type localhost:8090
````
 http://localhost:8090
````
 
> OOADJ Assignment 2023
